'use client'

import { useEffect, useState } from 'react'
import Link from 'next/link'
import { motion } from 'framer-motion'
import {
    ShoppingBag,
    Package,
    IndianRupee,
    TrendingUp,
    Clock,
    Plus,
    Ticket,
    Users,
    FolderTree
} from 'lucide-react'
import { useAuth } from '@/context/auth-context'

interface DashboardStats {
    totalOrders: number
    pendingOrders: number
    totalRevenue: number
    totalProducts: number
}


export default function AdminDashboard() {
    const { isAdmin } = useAuth()
    const [stats, setStats] = useState<DashboardStats>({
        totalOrders: 0,
        pendingOrders: 0,
        totalRevenue: 0,
        totalProducts: 0
    })
    const [isLoading, setIsLoading] = useState(true)

    useEffect(() => {
        fetchDashboardData()
    }, [])

    const fetchDashboardData = async () => {
        try {
            const response = await fetch('/api/admin/stats')
            const data = await response.json()

            if (data.success) {
                setStats(data.stats)
            }
        } catch (error) {
            console.error('Error fetching dashboard data:', error)
        } finally {
            setIsLoading(false)
        }
    }

    const statCards = [
        {
            title: 'Total Revenue',
            value: `₹${stats.totalRevenue.toLocaleString()}`,
            icon: IndianRupee,
            color: 'text-emerald-600',
            bgColor: 'bg-emerald-500/10',
            accent: 'emerald',
            trend: 'Income'
        },
        {
            title: 'Total Orders',
            value: stats.totalOrders,
            icon: ShoppingBag,
            color: 'text-blue-600',
            bgColor: 'bg-blue-500/10',
            accent: 'blue',
            trend: 'Serving'
        },
        {
            title: 'Pending Orders',
            value: stats.pendingOrders,
            icon: Clock,
            color: 'text-orange-600',
            bgColor: 'bg-orange-500/10',
            accent: 'orange',
            trend: 'Needs Attention'
        },
        {
            title: 'Total Products',
            value: stats.totalProducts,
            icon: Package,
            color: 'text-purple-600',
            bgColor: 'bg-purple-500/10',
            accent: 'purple',
            trend: 'Inventory'
        }
    ]

    return (
        <div className="min-h-screen bg-[#FEFBF5] relative overflow-hidden pt-32 pb-16">
            {/* Immersive Background Patterns */}
            <div className="absolute inset-0 z-0 pointer-events-none opacity-20">
                <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-saffron/20 rounded-full blur-[100px] -mr-64 -mt-64 animate-pulse" />
                <div className="absolute bottom-0 left-0 w-[500px] h-[500px] bg-magenta/10 rounded-full blur-[100px] -ml-64 -mb-64 animate-pulse animation-delay-2000" />
                <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-full h-full bg-[url('https://www.transparenttextures.com/patterns/p6.png')] opacity-10" />
            </div>

            <div className="container mx-auto px-4 max-w-7xl relative z-10">
                {/* Header */}
                <div className="mb-12 flex flex-col md:flex-row md:items-end justify-between gap-6 mt-10">
                    <div>
                        <motion.div
                            initial={{ opacity: 0, x: -20 }}
                            animate={{ opacity: 1, x: 0 }}
                            className="inline-flex items-center gap-2 px-3 py-1 bg-white/50 backdrop-blur-md rounded-full border border-orange-100 mb-4"
                        >
                            <TrendingUp className="h-4 w-4 text-saffron" />
                            <span className="text-[#4A3737] text-[10px] font-bold uppercase tracking-[0.2em]">Management Suite</span>
                        </motion.div>
                        <h1 className="text-[#2D1B1B] mb-2 font-bold tracking-tight" style={{ fontSize: 'clamp(1.5rem, 3vw, 2rem)', fontFamily: 'var(--font-heading)' }}>
                            Admin <span className="text-saffron">Overview</span>
                        </h1>
                        <p className="text-[#4A3737]/70 font-playfair text-lg">Your master control for the Mahek Provisions catalog and orders.</p>
                    </div>
                </div>

                {/* Stats Grid - Glassmorphism */}
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
                    {statCards.map((stat, index) => (
                        <motion.div
                            key={stat.title}
                            initial={{ opacity: 0, y: 20 }}
                            animate={{ opacity: 1, y: 0 }}
                            transition={{ delay: index * 0.1 }}
                            className="group relative bg-white/60 backdrop-blur-xl rounded-[2rem] border border-white/40 p-8 shadow-[0_8px_32px_rgba(217,119,6,0.05)] hover:shadow-[0_20px_48px_rgba(217,119,6,0.12)] transition-all duration-500"
                        >
                            <div className="flex items-center justify-between mb-6">
                                <div className={`${stat.bgColor} p-4 rounded-2xl group-hover:scale-110 transition-transform duration-500`}>
                                    <stat.icon className={`h-6 w-6 ${stat.color}`} />
                                </div>
                                <span className={`text-[10px] font-bold px-2 py-1 rounded-full ${stat.accent === 'orange' ? 'bg-orange-100 text-orange-600' : 'bg-emerald-100 text-emerald-600'}`}>
                                    {stat.trend}
                                </span>
                            </div>
                            <h3 className="text-[#4A3737]/60 text-xs font-bold uppercase tracking-widest mb-1 font-playfair">{stat.title}</h3>
                            <p className="text-3xl font-bold text-[#2D1B1B] font-cinzel tracking-tight">{stat.value}</p>

                            {/* Decorative line */}
                            <div className={`absolute bottom-0 left-8 right-8 h-1 rounded-t-full transition-all duration-500 opacity-0 group-hover:opacity-100 ${stat.accent === 'emerald' ? 'bg-emerald-400' :
                                stat.accent === 'blue' ? 'bg-blue-400' :
                                    stat.accent === 'orange' ? 'bg-orange-400' : 'bg-purple-400'
                                }`} />
                        </motion.div>
                    ))}
                </div>

                {/* Command Center - Premium Action Tiles */}
                <h2 className="text-[#2D1B1B] mb-6 flex items-center gap-3" style={{ fontSize: '1.25rem', textAlign: 'left', fontFamily: 'var(--font-heading)' }}>
                    <span className="w-8 h-px bg-saffron" />
                    Command Center
                    <span className="w-8 h-px bg-saffron" />
                </h2>
                <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-12">
                    <Link href="/admin/add-product">
                        <motion.div
                            whileHover={{ y: -8, scale: 1.02 }}
                            className="relative h-48 bg-gradient-to-br from-saffron via-orange-500 to-orange-600 rounded-[2.5rem] shadow-xl overflow-hidden group cursor-pointer"
                        >
                            <div className="absolute top-0 left-0 w-32 h-32 bg-white/30 rounded-full -ml-16 -mt-16 group-hover:scale-150 transition-transform duration-700" />
                            <div className="relative h-full p-7 flex flex-col justify-between text-white">
                                <div className="bg-white/20 w-12 h-12 rounded-2xl flex items-center justify-center backdrop-blur-md">
                                    <Plus className="h-6 w-6" />
                                </div>
                                <div>
                                    <h3 className="font-cinzel text-2xl font-bold mb-1 text-[#2D1B1B]">Add Product</h3>
                                    <p className="text-white/80 text-sm font-playfair">Grow your digital orchard</p>
                                </div>
                            </div>
                        </motion.div>
                    </Link>

                    <Link href="/admin/orders">
                        <motion.div
                            whileHover={{ y: -8, scale: 1.02 }}
                            className="relative h-48 bg-gradient-to-br from-magenta via-pink-600 to-rose-700 rounded-[2.5rem] shadow-xl overflow-hidden group cursor-pointer"
                        >
                            <div className="absolute top-0 left-0 w-32 h-32 bg-white/30 rounded-full -ml-16 -mt-16 group-hover:scale-150 transition-transform duration-700" />
                            <div className="relative h-full p-7 flex flex-col justify-between text-white">
                                <div className="bg-white/20 w-12 h-12 rounded-2xl flex items-center justify-center backdrop-blur-md">
                                    <ShoppingBag className="h-6 w-6" />
                                </div>
                                <div>
                                    <h3 className="font-cinzel text-2xl font-bold mb-1 text-[#2D1B1B]">View Orders</h3>
                                    <p className="text-white/80 text-sm font-playfair">Manage customer joy</p>
                                </div>
                            </div>
                        </motion.div>
                    </Link>

                    <Link href="/admin/products">
                        <motion.div
                            whileHover={{ y: -8, scale: 1.02 }}
                            className="relative h-48 bg-gradient-to-br from-indigo-300 via-purple-600 to-fuchsia-700 rounded-[2.5rem] shadow-xl overflow-hidden group cursor-pointer"
                        >
                            <div className="absolute top-0 left-0 w-32 h-32 bg-white/30 rounded-full -ml-16 -mt-16 group-hover:scale-150 transition-transform duration-700" />
                            <div className="relative h-full p-7 flex flex-col justify-between text-white">
                                <div className="bg-white/20 w-12 h-12 rounded-2xl flex items-center justify-center backdrop-blur-md">
                                    <Package className="h-6 w-6" />
                                </div>
                                <div>
                                    <h3 className="font-cinzel text-2xl font-bold mb-1 text-[#2D1B1B]">Manage Products</h3>
                                    <p className="text-white/80 text-sm font-playfair">Orchestrate the collection</p>
                                </div>
                            </div>
                        </motion.div>
                    </Link>

                    <Link href="/admin/coupons">
                        <motion.div
                            whileHover={{ y: -8, scale: 1.02 }}
                            className="relative h-48 bg-gradient-to-br from-teal-400 via-emerald-500 to-green-600 rounded-[2.5rem] shadow-xl overflow-hidden group cursor-pointer"
                        >
                            <div className="absolute top-0 left-0 w-32 h-32 bg-white/30 rounded-full -ml-16 -mt-16 group-hover:scale-150 transition-transform duration-700" />
                            <div className="relative h-full p-7 flex flex-col justify-between text-white">
                                <div className="bg-white/20 w-12 h-12 rounded-2xl flex items-center justify-center backdrop-blur-md">
                                    <Ticket className="h-6 w-6" />
                                </div>
                                <div>
                                    <h3 className="font-cinzel text-2xl font-bold mb-1 text-[#2D1B1B]">Manage Coupons</h3>
                                    <p className="text-white/80 text-sm font-playfair">Promotional treasures</p>
                                </div>
                            </div>
                        </motion.div>
                    </Link>

                    <Link href="/admin/categories">
                        <motion.div
                            whileHover={{ y: -8, scale: 1.02 }}
                            className="relative h-48 bg-gradient-to-br from-amber-400 via-yellow-500 to-orange-500 rounded-[2.5rem] shadow-xl overflow-hidden group cursor-pointer"
                        >
                            <div className="absolute top-0 left-0 w-32 h-32 bg-white/30 rounded-full -ml-16 -mt-16 group-hover:scale-150 transition-transform duration-700" />
                            <div className="relative h-full p-7 flex flex-col justify-between text-white">
                                <div className="bg-white/20 w-12 h-12 rounded-2xl flex items-center justify-center backdrop-blur-md">
                                    <FolderTree className="h-6 w-6" />
                                </div>
                                <div>
                                    <h3 className="font-cinzel text-2xl font-bold mb-1 text-[#2D1B1B]">Manage Categories</h3>
                                    <p className="text-white/80 text-sm font-playfair">Organize products</p>
                                </div>
                            </div>
                        </motion.div>
                    </Link>

                    {isAdmin && (
                        <Link href="/admin/users">
                            <motion.div
                                whileHover={{ y: -8, scale: 1.02 }}
                                className="relative h-48 bg-gradient-to-br from-slate-400 via-slate-600 to-slate-800 rounded-[2.5rem] shadow-xl overflow-hidden group cursor-pointer"
                            >
                                <div className="absolute top-0 left-0 w-32 h-32 bg-white/30 rounded-full -ml-16 -mt-16 group-hover:scale-150 transition-transform duration-700" />
                                <div className="relative h-full p-7 flex flex-col justify-between text-white">
                                    <div className="bg-white/20 w-12 h-12 rounded-2xl flex items-center justify-center backdrop-blur-md">
                                        <Users className="h-6 w-6" />
                                    </div>
                                    <div>
                                        <h3 className="font-cinzel text-2xl font-bold mb-1 text-white">Manage Users</h3>
                                        <p className="text-white/80 text-sm font-playfair">Roles & permissions</p>
                                    </div>
                                </div>
                            </motion.div>
                        </Link>
                    )}
                </div>
            </div>
        </div>
    )
}
