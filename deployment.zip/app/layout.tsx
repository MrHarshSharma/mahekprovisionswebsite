
import type { Metadata, Viewport } from 'next'
import Script from 'next/script'
import './globals.css'
import Navbar from '@/components/navbar'
import { CartProvider } from '@/context/cart-context'
import { AuthProvider } from '@/context/auth-context'
import CartDrawer from '@/components/cart-drawer'
import ServiceWorkerRegister from '@/components/sw-register'

import { Suspense } from 'react'

const siteUrl = process.env.NEXT_PUBLIC_APP_URL || 'https://mahekprovisions.com/'

export const viewport: Viewport = {
  width: 'device-width',
  initialScale: 1,
  maximumScale: 5,
  themeColor: '#f7b700',
}

export const metadata: Metadata = {
  metadataBase: new URL(siteUrl),
  title: {
    default: 'Mahek Provisions | Quality Groceries & Provisions Store in Digras',
    template: '%s | Mahek Provisions'
  },
  description: 'Shop quality groceries, daily essentials & provisions online at Mahek Provisions. Your trusted neighborhood store in Digras, Maharashtra since 1916. Fast delivery & best prices!',
  keywords: [
    'Mahek Provisions',
    'grocery store Digras',
    'provisions shop',
    'online groceries',
    'daily essentials',
    'grocery delivery Digras',
    'kirana store online',
    'household items',
    'quality provisions',
    'grocery shopping online',
    'Mahek Provision Digras',
    'Maharashtra grocery store'
  ],
  authors: [{ name: 'Mahek Provisions' }],
  creator: 'Mahek Provisions',
  publisher: 'Mahek Provisions',
  formatDetection: {
    email: false,
    address: false,
    telephone: false,
  },
  icons: {
    icon: [
      { url: '/logo.png', sizes: '32x32', type: 'image/png' },
      { url: '/logo.png', sizes: '192x192', type: 'image/png' },
    ],
    apple: [
      { url: '/logo.png', sizes: '180x180', type: 'image/png' },
    ],
    shortcut: '/logo.png',
  },
  manifest: '/manifest.json',
  openGraph: {
    type: 'website',
    locale: 'en_IN',
    url: siteUrl,
    siteName: 'Mahek Provisions',
    title: 'Mahek Provisions | Quality Groceries & Provisions Store',
    description: 'Shop quality groceries, daily essentials & provisions online. Your trusted store in Digras since 1916. Fast delivery!',
    images: [
      {
        url: '/og-image.png',
        width: 1200,
        height: 630,
        alt: 'Mahek Provisions - Quality Groceries & Provisions',
      },
    ],
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Mahek Provisions | Quality Groceries & Provisions',
    description: 'Shop quality groceries & daily essentials online. Trusted store in Digras since 1916.',
    images: ['/og-image.png'],
    creator: '@mahekprovisions',
  },
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      'max-video-preview': -1,
      'max-image-preview': 'large',
      'max-snippet': -1,
    },
  },
  alternates: {
    canonical: siteUrl,
  },
  category: 'ecommerce',
}

import Footer from '@/components/footer'
import MarqueeBanner from '@/components/marquee-banner'
import PullToRefresh from '@/components/pull-to-refresh'

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en">
      <head>
        <Script
          src="https://www.googletagmanager.com/gtag/js?id=G-5P3EK1TNQZ"
          strategy="afterInteractive"
        />
        <Script id="google-analytics" strategy="afterInteractive">
          {`
            window.dataLayer = window.dataLayer || [];
            function gtag(){dataLayer.push(arguments);}
            gtag('js', new Date());
            gtag('config', 'G-5P3EK1TNQZ');
          `}
        </Script>
      </head>
      <body className="antialiased flex flex-col min-h-screen font-sans">
        <AuthProvider>
          <CartProvider>
            <PullToRefresh />
            <ServiceWorkerRegister />
            <Navbar />
            <MarqueeBanner />
            <Suspense fallback={null}>
              <CartDrawer />
            </Suspense>
            <main className="flex-grow">
              {children}
            </main>
            <Footer />
          </CartProvider>
        </AuthProvider>
      </body>
    </html>
  )
}
